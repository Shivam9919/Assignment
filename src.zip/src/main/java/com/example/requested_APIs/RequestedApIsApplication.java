package com.example.requested_APIs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class RequestedApIsApplication {

    public static void main(String[] args) {
        SpringApplication.run(RequestedApIsApplication.class, args);
    }

}
