package com.example.requested_APIs.jwt;

import com.example.requested_APIs.model.User;
import com.example.requested_APIs.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class JwtUtils {

    @Autowired
    private UserService userService;

    // Method to extract username from the JWT token
    public String extractUsername(String token) {
        // Logic to extract the username from the token
        // You can use a JWT library to decode the token and extract the username
        return "extractedUsername";  // Example; replace with actual logic
    }

    // Method to get the user details from the token using UserService
    public User getUserFromToken(String token) {
        String username = extractUsername(token);
        return userService.findUserByUsername(username);  // Fetch user details from the UserService
    }
}
