package com.example.requested_APIs.model;

public enum Priority {
    HIGH, MEDIUM, LOW
}
