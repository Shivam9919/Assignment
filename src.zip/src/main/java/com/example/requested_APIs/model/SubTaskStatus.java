package com.example.requested_APIs.model;

public enum SubTaskStatus {
    TODO,
    IN_PROGRESS,
    DONE
}
