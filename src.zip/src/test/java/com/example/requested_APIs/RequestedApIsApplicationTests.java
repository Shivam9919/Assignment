package com.example.requested_APIs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RequestedApIsApplicationTests {

	@Test
	void contextLoads() {
	}

}
